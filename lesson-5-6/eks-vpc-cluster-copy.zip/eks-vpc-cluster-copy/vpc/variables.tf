variable "aws_region" {}
variable "project_name" {}

variable "vpc_cidr" {
  default = "10.0.0.0/16"
}